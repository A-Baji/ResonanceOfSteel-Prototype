using Godot;

namespace ResonanceOfSteel.Bridge
{
	public partial class MainCoordinator : Node
	{
		// Fields using [Export] must be here, outside of any methods.
		// However, using the runtime path approach below is more robust for 
		// the RemoteTransform3D architecture.

		public override void _Ready()
		{
			// 1. Access the Viewports
			// Adjust paths to match your Main.tscn hierarchy exactly
			var vp1 = GetNode<SubViewport>("Control/HBoxContainer/SubViewportContainer1/ViewportP1");
			var vp2 = GetNode<SubViewport>("Control/HBoxContainer/SubViewportContainer2/ViewportP2");

			// 2. Access the Game World (instanced in Main.tscn)
			var gameWorld = GetNode<Node3D>("GameScene");

			// 3. Synchronize the 3D Worlds
			// This ensures both viewports render the same physical objects
			vp2.World3D = vp1.World3D;

			// 4. Connect the RemoteTransforms to the Viewport Cameras
			// These nodes live inside the GameScene but drive the cameras in the Main UI
			var remoteP1 = gameWorld.GetNode<RemoteTransform3D>("Player1/CameraLinkP1");
			var remoteP2 = gameWorld.GetNode<RemoteTransform3D>("Player2/CameraLinkP2");

			var camP1Path = vp1.GetNode<Camera3D>("CameraP1").GetPath();
			var camP2Path = vp2.GetNode<Camera3D>("CameraP2").GetPath();

			remoteP1.RemotePath = camP1Path;
			remoteP2.RemotePath = camP2Path;
		}
	}
}